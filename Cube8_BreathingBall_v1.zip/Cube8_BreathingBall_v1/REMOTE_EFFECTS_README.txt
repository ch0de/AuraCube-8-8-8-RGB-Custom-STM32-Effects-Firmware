Cube8 Triple Effects + Manual RGB Remote v2
===========================================

Built from the known-good Cube8_DualEffects_Remote_v1 baseline.

MODES
-----
1  Smooth whole-cube hue sweep
2  Vivid 3-D cloud swirl
3  Manual solid RGB color
MODE/TEST cycles 1 -> 2 -> 3 -> 1

COMMON CONTROLS
---------------
+      Brightness up
-      Brightness down
FF     Faster (animated modes)
REW    Slower (animated modes)
PLAY   Pause/resume (animated modes)
POWER  Display off/on, retaining settings
0      Reset defaults

MANUAL RGB MODE (press 3)
-------------------------
4 = Red up       7 = Red down
5 = Green up     8 = Green down
6 = Blue up      9 = Blue down

PLAY = select active channel: Red -> Green -> Blue -> Red
FF   = selected channel up
REW  = selected channel down

The direct 4/7, 5/8, and 6/9 controls remain available at all times in Manual RGB mode.
RGB channel step: 8 counts per press, each channel 0..255.
Manual brightness starts at 25% but is NOT capped. + can raise it to 100%.
Manual brightness changes by 16 counts per press and saturates at 0 or 255.
Manual R/G/B/brightness values are remembered while changing modes.

IMPORTANT POWER NOTE
--------------------
The animated modes retain the known-good capped brightness table from the
previous project.  Manual RGB intentionally allows full output as requested.
At high manual brightness, especially white (R=G=B=255), the cube can draw
substantially more current and may reproduce the buzzing/layer flicker seen
during earlier full-brightness testing.
