Cube8 Breathing / Bouncing Ball v1

New fifth effect mode (MODE/TEST cycles into it after Diagnostic):

  Centered breathing ball:
    - Starts as a small sphere in the center.
    - Smoothly expands until the sphere fills all 8x8x8 voxels.
    - Smoothly contracts and repeats.
    - Soft anti-aliased edge fades voxels in/out to reduce radius stepping.

  Ball-mode remote controls:
    + / -       brightness up/down (same safe animated brightness range)
    FF / REW    speed up/down (controls breathing, hue rotation, and bounce speed)
    PLAY        toggle bouncing center on/off
    0           toggle smooth hue rotation / single manual RGB color
    4 / 7       red up/down for single-color ball
    5 / 8       green up/down for single-color ball
    6 / 9       blue up/down for single-color ball
    POWER       display off/on, settings retained
    MODE/TEST   next effect mode

Single-color mode shares the manual RGB values with Manual RGB mode, so colors
set in either mode carry into the other.  Hue mode is full saturation and
rotates continuously without stepped degree truncation.

The existing Hue, Cloud, Manual RGB, and Diagnostic modes are retained.
