Cube8 Diagnostic Slices v2

Existing modes retained:
  1 = smooth whole-cube hue sweep
  2 = vivid cloud swirl
  3 = manual solid RGB

Diagnostic mode:
  MODE/TEST cycles into a fourth mode after Manual RGB.
  On entry it starts: Layer 1, WHITE, 100% brightness.

Diagnostic controls:
  PLAY = cycle White -> Red -> Green -> Blue -> White
  FF   = next SINGLE layer/row, wrapping 8 -> 1 (returns cumulative count to 1)
  REW  = previous SINGLE layer/row, wrapping 1 -> 8 (returns cumulative count to 1)
  4    = ADD one cumulative layer/row: 1 -> 2 -> 3 -> ... -> 8
         Example in Layer mode: 1 lights layer 1; next press lights 1+2; then 1+2+3, etc.
  7    = REMOVE one cumulative layer/row: 8 -> 7 -> ... -> 1
  0    = toggle Horizontal Layers <-> Vertical Row planes; resets to one slice
  +    = brightness up
  -    = brightness down
  POWER = display off/on
  MODE/TEST = leave diagnostic / cycle modes

Coordinates:
  Layer mode uses horizontal physical Y layers (Y=0..7).
  Row mode uses vertical Z planes (Z=0..7), 64 LEDs per plane.

Purpose:
  Single-slice FF/REW isolates one driver/plane at a time.
  Cumulative 4/7 testing increases or decreases electrical load one 64-LED plane at a time,
  making it easier to find the exact number of active layers/rows where flicker begins.


V3 diagnostic changes
---------------------
- FF / REW now slide the complete active block without resetting the count.
  Example with 3 layers active: 1-3 -> 2-4 -> 3-5 -> ... -> 6-8.
- 4 / 7 still add/remove one active adjacent layer or row.
- Added ~1 us-class blanking/settling delays around Aura layer address/latch
  changes to test whether full-white flashes on inactive layers are switching
  ghosting. Animated/manual modes remain otherwise unchanged.


=== v4 diagnostic changes ===
- Row numbering reversed so diagnostic Row 1 corresponds to the physical Row 1 observed on the cube.
- Cumulative/sliding layer and row controls are unchanged.
- In Diagnostic mode only, scan order is now:
    OE OFF -> long blank -> shift/latch NEXT RGB while OLD layer remains selected
    -> long settle -> select NEXT HC138 layer -> long settle -> OE ON
- Long diagnostic settle delay is intentionally about 5 us (plus loop overhead).
- Hue, cloud, and manual RGB modes keep the v3 scan sequence unchanged.

Repeat the useful white test with 1+2, 2+3, 3+4, etc., and note whether the phantom layer 7/8 flashes and fixed green/red ghost pixels change.
